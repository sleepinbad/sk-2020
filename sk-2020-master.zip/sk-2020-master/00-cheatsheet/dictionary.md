## Słowniczek

* TUN/TAP interface
* Router
* Gateway
* Packet forwarding
* NAT
* Switch
* Domena rozgłoszeniowa
* Domena kolizyjna ()

...